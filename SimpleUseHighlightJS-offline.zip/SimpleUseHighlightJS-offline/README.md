## 说明

1. highlight不能直接使用GitHub上的源代码，需要编译。(详见 "Don't link to GitHub directly. The library is not supposed to work straight from the source, it requires building. If none of the pre-packaged options work for you refer to the building documentation." ===> https://highlightjs.org/usage/)

2. 如果是离线版，那么 ===> https://highlightjs.org/download/ ===> Custom package, 选定所需语言 ===> download ===> highlight.zip ===> 解压 ===> 按照 https://highlightjs.org/usage/ 的说明，仿照Template模板设置css和js

3. 如果是使用cdn, 那么按照 https://highlightjs.org/usage/ 的说明，直接仿照Template模板设置css和js即可