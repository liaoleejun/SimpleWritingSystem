# Notes
Download the master branch, then open template.html to see the effect of the demo (please ensure that there is Internet access, otherwise it will report an error, because the master branch uses the way to load js online).

Or download the "offline" branch, then directly open template.html to see the effect of the demo (no internet access required, because the offline branch contains all the required js files locally).

# References
1. Wagner, J. (2011, February 26). "html - Automatic Numbering of Headings H1-H6 using jQuery - Stack Overflow". Retrieved from https://stackoverflow.com/a/5127570/7843026<br>Accessed on: 2019-02-16. Archived at: https://web.archive.org/web/20190216154138/https://stackoverflow.com/questions/5127017/automatic-numbering-of-headings-h1-h6-using-jquery/5127570#5127570
2. jquery auto add number section to header - Google Search
