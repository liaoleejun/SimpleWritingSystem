# Notes
Download the master branch, then open template.html to see the effect of the demo (please ensure that there is Internet access, otherwise it will report an error, because the master branch uses the way to load js online).

Or download the "offline" branch, then directly open template.html to see the effect of the demo (no internet access required, because the offline branch contains all the required js files locally).

# References
1. Jovanovic, J. (2009, August 20). "Automatically generate table of contents using jQuery". Retrieved from http://www.jankoatwarpspeed.com/automatically-generate-table-of-contents-using-jquery/<br>Accessed on: 2019-02-14. Archived at: https://web.archive.org/web/20190214075257/http://www.jankoatwarpspeed.com/automatically-generate-table-of-contents-using-jquery/.
2. Jovanovic, J. "Automatically generate table of contents using jQuery - Demo 2 - Janko At Warp Speed demos". Retrieved from http://www.jankoatwarpspeed.com/wp-content/uploads/examples/table-of-contents/demo2.html<br>Accessed on: 2019-02-14. Archived at: https://web.archive.org/web/20190214144931/http://www.jankoatwarpspeed.com/wp-content/uploads/examples/table-of-contents/demo2.html